Changing scope values asynchronously - updates propagate .apply().
