Adding a controller to our custom directive
