Caching JSON data in a service.
