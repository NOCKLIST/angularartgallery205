Preparing for routing - making a simple country listing.
