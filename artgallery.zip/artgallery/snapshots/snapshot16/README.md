Clearing the entered name on submit using data binding.
