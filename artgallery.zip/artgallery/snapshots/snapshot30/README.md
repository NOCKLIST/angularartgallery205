Adding GDP data
