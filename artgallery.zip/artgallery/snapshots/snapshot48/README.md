Fetching data within custom directives - adding flags to the country listing.
