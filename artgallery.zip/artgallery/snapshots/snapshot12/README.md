Changing scope values asynchronously - updates don't propagate without .apply().

See also [Angular docs on `$scope`](http://docs.angularjs.org/api/ng/type/$rootScope.Scope) (explains `$watch` and `$apply`).
