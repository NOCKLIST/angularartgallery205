Sorting table columns interactively.

Inspired by [Angular orderBy docs](http://docs.angularjs.org/api/ng/filter/orderBy).
