Extracting text from the text input as it changes.
