Creating a custom filter to encode URIs

Inspired by:

 * [Angular official tutorial step 9](http://docs.angularjs.org/tutorial/step_09)
 * [How to generate url encoded anchor links with AngularJS? on StackOverflow](http://stackoverflow.com/questions/14512583/how-to-generate-url-encoded-anchor-links-with-angularjs)
 * [Best practice: escape, or encodeURI / encodeURIComponent on StackOverflow](http://stackoverflow.com/questions/75980/best-practice-escape-or-encodeuri-encodeuricomponent)
