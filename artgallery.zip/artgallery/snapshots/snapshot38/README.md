Looking up details for a single country
