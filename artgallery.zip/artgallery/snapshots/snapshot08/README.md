Data binding with many text inputs.
