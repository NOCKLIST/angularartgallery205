Extracting and using parameters from routes
