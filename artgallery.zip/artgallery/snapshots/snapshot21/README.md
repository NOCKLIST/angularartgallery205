Dependency injection syntax for minification.

See also [Angular Dependency Injection Docs](http://docs.angularjs.org/guide/di).
