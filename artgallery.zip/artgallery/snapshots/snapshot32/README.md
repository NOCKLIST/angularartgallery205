Formatting population using Angular filters in templates.

See [Angular number filter docs](http://docs.angularjs.org/api/ng/filter/number).
