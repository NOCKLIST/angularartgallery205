Fetching JSON using Angular's `$http` service.

See also [Angular docs on `$http`](http://docs.angularjs.org/api/ng/service/$http).
