Interactively reversing sort order.
