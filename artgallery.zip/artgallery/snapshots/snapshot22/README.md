Adding search using Angular filters.

See [Angular filter docs](http://docs.angularjs.org/api/ng/filter/filter).
