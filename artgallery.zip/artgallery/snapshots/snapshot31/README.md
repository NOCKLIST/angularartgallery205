Formatting currency using Angular filters in templates.

See [Angular currency filter docs](http://docs.angularjs.org/api/ng/filter/currency).
