Using ng-src.
