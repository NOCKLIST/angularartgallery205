angular.module('productsFactory', [])
       .factory('products', function($http){
  return {
    list: function (callback){
      $http({
        method: 'GET',
        url: 'products.json',
        cache: true
      }).success(callback);
    },
    

    find: function(id, callback){
      $http({
        method: 'GET',
        url: 'product_' + id + '.json',
        cache: true
      }).success(callback);
    }
  };
});
