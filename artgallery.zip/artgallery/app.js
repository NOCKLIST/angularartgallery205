var productApp = angular.module('productApp', [
  'ngRoute',
  'productControllers',
  'productsFactory',
  'productDirective'
]);

productApp.config(function($routeProvider) {
  $routeProvider.
    when('/', {
      templateUrl: 'product-list.html',
      controller: 'ProductListCtrl'
    }).
    when('/:productId', {
      templateUrl: 'product-detail.html',
      controller: 'ProductDetailCtrl'
    }).
    otherwise({
      redirectTo: '/'
    });
});
